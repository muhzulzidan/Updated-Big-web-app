import "./style.css";
// import backArrow from "../../assets/svgs/back-arrow.svg";
// import cross from "../../assets/svgs/dark-cross.svg";
import React, { useEffect, useState } from "react";


import { BrowserRouter, Switch as Sw, Route, Link } from "react-router-dom";



import { ReactComponent as Catalogcheck } from "../../../assets/catalogcheck.svg";
import { ReactComponent as Folder } from "../../../assets/folder.svg";
import { ReactComponent as Check } from "../../../assets/check.svg";
import { ReactComponent as Fullscreen } from "../../../assets/fullscreen.svg";
// import industryIcon from "../../../../../assets/svgs/industry.svg";

import TextInput from "../../../../../components/inputs/text-input";
import Select from "../../../../../components/inputs/select";
import ImageUpload from "../../../../../components/inputs/image-upload";

import FormControlLabel from '@material-ui/core/FormControlLabel';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Switch from '@material-ui/core/Switch';



import AddProduct from "./addProduct"

import "./create-mode.css"

export default function Catalog({ title, children, visible, setVisibility }) {

    const [showSidePanel, setShowSidePanel] = useState(false);
    const [product, setproduct] = useState({});
    const [tempProduct, setTempProduct] = useState({});

    const useStyles = makeStyles({
        root: {
    
        },
        label: {
          fontSize: "calc(23px + 1vw)",
          paddingRight: "9em",
          color:"var(--blue-1)",
          fontWeight:"600",
        },
      });

    const classes = useStyles();
    const IOSSwitch = withStyles((theme) => ({
        root: {
          width: 65,
          height: 35,
          padding: 0,
          margin: theme.spacing(1),
          display: "flex",
          justifyContent: "space-between"
        },
        switchBase: {
          color: "#C4C4C4",
          padding: 1,
          '&$checked': {
            transform: 'translateX(32px)',
            color: "#C4C4C4",
            '& + $track': {
              backgroundColor: '#959595',
              opacity: 1,
              border: 'none',
            },
          },
          '&$focusVisible $thumb': {
            color: '#001d53',
            border: '6px solid #C4C4C4',
          },
        },
        thumb: {
          width: 32,
          height: 32,
          color:"var(--blue-1)",
        },
        track: {
          borderRadius: 32 / 2,
          border: `1px solid ${theme.palette.grey[400]}`,
          backgroundColor: theme.palette.grey[50],
          opacity: 1,
          transition: theme.transitions.create(['background-color', 'border']),
        },
        checked: {},
        focusVisible: {},
      }))(({ classes, ...props }) => {
        return (
          <Switch
            focusVisibleClassName={classes.focusVisible}
            disableRipple
            classes={{
              root: classes.root,
              switchBase: classes.switchBase,
              thumb: classes.thumb,
              track: classes.track,
              checked: classes.checked,
            }}
            size="medium"
            {...props}
          />
        );
      });
    
      const [state, setState] = React.useState({
        Active: false,
      });

      const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
      };

      const saveMenu = () => {

        //hide panel
        setShowSidePanel(false);
      };

    return (
        // <BrowserRouter>
        <div className={`catalog`} >
            <div className="flex-grow-1" ></div>
            <div className="side-panel" style={{
                position: "relative",
            }}>
                <div className="side-panel-status-bar ">
                    <div className="create-catalog-container">
                        <div className="create-catalog">
                            <button onClick={() => setShowSidePanel(true)}>
                                Create Mode
                        </button>
                        </div>
                        <button>
                            <Catalogcheck className="catalog-check" />
                        </button>
                        <button>
                            <Folder className="folder" />
                        </button>
                        <button>
                            <Check className="check" />
                        </button>
                        <button>
                            <Fullscreen className="fullscreen" />
                        </button>
                    </div>
                    <div className="side-panel-title">
                        {title}
                    </div>
                </div>
                {children}

                <AddProduct
                    title={`Add Product`}
                    visible={showSidePanel}
                    setVisibility={setShowSidePanel}
                >
                    <div className="product-container">
                        <div className="product-left">
                            <Select
                                // icon={industryIcon}
                                value={product.productType}
                                setValue={(val) => {
                                    setproduct({
                                        ...product,
                                        productType: val,
                                    });
                                }}
                                placeholder="Select Product Type"

                                style={{
                                    width: "91%",
                                    display: "flex",
                                    alignSelf: "center",
                                    padding: "25px",
                                    marginBottom: "1em",
                                    marginLeft: "auto",
                                    marginRight: "auto",
                                }}
                            >
                                <option value="item">Item</option>
                                <option value="group">Group</option>
                            </Select>
                            <TextInput
                                style={{
                                    width: "91%",
                                    "margin-left": "auto",
                                    "marginRight": "auto",
                                }}
                                value={product.name ? product.name : ""}
                                setValue={(val) => {
                                    setproduct({
                                        ...product,
                                        name: val,
                                    });
                                }}
                                placeholder="Name"

                            />
                            <div className="catalog-details">
                                <p>Add Description</p>
                                <p>Add Allergens</p>
                                <p>Add Calories</p>
                                <p>Add SKU</p>
                                <p>Add Min/Max</p>
                                <p>Add Items</p>
                            </div>
                        </div>
                        <div className="product-right">
                            <div className="image-upload .mx-auto">
                                <ImageUpload className="h-100"
                                    // text="Upload Image" 
                                    handleUpload={(url) => {
                                        setTempProduct({ ...tempProduct, image: url });
                                    }} />
                            </div>
                            <FormControlLabel
                                control={
                                <IOSSwitch size="large" checked={state.Active} onChange={handleChange} name="Active" />
                                }
                                label="Active"
                                labelPlacement="start"
                                classes={{
                                label: classes.label,
                                }}
                            />
                            <div className="catalog-details">
                                <p>Add Minimum Quantity</p>
                                <p>Add Maximum Quantity</p>
                                <p>Add Measurement Unit</p>
                            </div>
                        </div>
                    </div>
                    <div className="bottom-container">
                            <button onClick={saveMenu}>
                                Save
                            </button>
                            <div className="price">
                                <p>Add Base Price</p>
                                <TextInput
                                    style={{
                                        width: "45%",
                                        "margin-left": "auto",
                                        "marginRight": "auto",
                                    }}
                                    value={product.price ? product.price : ""}
                                    setValue={(val) => {
                                        setproduct({
                                            ...product,
                                            price: val,
                                        });
                                    }}
                                    placeholder="Listing Price"
    
                                />
                            </div>
                    </div>
                </AddProduct>
            </div>
            {/* <div style={{ flex: 4,  }}>

            <Sw>
                <Route path="/product-detail">
                    <div className="product-details-container">
                    <div className="product-head">
                        <h3>
                        Product Name
                        </h3>
                        <h3>
                        SR 45.00
                        </h3>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim quibusdam perspiciatis aut modi cumque quis ipsam quia ipsum magni itaque tempore vel adipisci nostrum, quod, dolores maxime. Pariatur, dolorem itaque.</p>
                        <br />
                        <p>Images</p>
                        <hr />
                    <div>
                    </div>
                    </div>
                </Route>
            </Sw>

        </div>                                     */}
        </div>
    // </BrowserRouter> 
    );
}