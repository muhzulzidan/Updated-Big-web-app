import { useLogout } from "../../contexts/auth-context"
import "./style.css";
import arrow from "../../assets/svgs/arrow.svg";
import branch from "../../assets/svgs/branch.svg";
import role from "../../assets/svgs/role.svg";
import employee from "../../assets/svgs/employee.svg";
import schedule from "../../assets/svgs/schedule.svg";
import profile from "../../assets/svgs/profile.png";
import NavButton from "./nav-button";
import { useState } from "react";


export default function SideNav(props) {
    const logout = useLogout();
    const [shrink, setShrink] = useState(false);

    return (
        <div className={`side-nav ${shrink?"side-nav-collapse":""}`}>
            <div className="nav-title-bar">
                <div className="nav-header">Store</div>
                <img className="clickable side-nav-collapse-button" src={arrow} alt="logout" onClick={() => {
                    setShrink(!shrink);
                }}/>
            </div>
            <hr />
            <NavButton icon={branch} text="Branch" path="/"/>
            <NavButton icon={role} text="Role" path="/role"/>
            <NavButton icon={employee} text="Employee" path="/employee"/>
            <NavButton icon={schedule} text="Schedule" path="/schedule"/>
            <NavButton icon={employee} text="Catalog" path="/menu-manager-page"/>
            <div className="nav-profile">
                <img src={profile} alt="profile"/>
                <div>
                    User name
                    <div className="text-danger text-center h6 clickable" onClick={logout}>Logout</div>
                </div>
            </div>
        </div>
    );
}