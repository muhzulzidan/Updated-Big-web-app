export { default as numberInRange } from './numberInRange';
