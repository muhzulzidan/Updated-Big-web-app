Library by: jeongsd
https://github.com/jeongsd/react-timezone-map-gl
