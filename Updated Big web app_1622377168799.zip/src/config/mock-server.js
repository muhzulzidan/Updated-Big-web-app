const MOCK_SERVER_URL = "https://b87f7063-7199-4878-b7d8-a6d776ef29d9.mock.pstmn.io";
export default MOCK_SERVER_URL;