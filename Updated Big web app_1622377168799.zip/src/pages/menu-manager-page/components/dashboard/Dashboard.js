import React, { useState } from "react";
import DashBar from "./DashSidebar";
import Catalog from "./components/catalog";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";

import Product from "./components/Product"
import types from "./array/catalogItems"

export default function  Dashboard() {

    return (
    <div id="l-dashboard">
        <DashBar />
    </div>
  )
}


