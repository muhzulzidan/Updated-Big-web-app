 const types = [
    {
        name: 'Catalog A',
        slug: 'catalog-a'
    },
    {
        name: 'Catalog B',
        slug: 'catalog-b'
    },
    {
        name: 'Catalog C',
        slug: 'catalog-c'
    },
    {
        name: 'Catalog D',
        slug: 'catalog-d'
    },
]

export default types