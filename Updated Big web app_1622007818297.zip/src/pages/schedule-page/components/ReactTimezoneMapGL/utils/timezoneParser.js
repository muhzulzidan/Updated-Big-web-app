export default function timezoneParser(timezone) {
    return timezone.replace('±', '+')
}
  