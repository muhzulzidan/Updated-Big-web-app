
 const products = [
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:true,
    },
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:true,
    },
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:true,
    },
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:true,
    },
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:true,
    },
    {
        name: 'Product Name',
        detail: 'SR 45.00',
        green:false,
    },
]

export default products