import AF from "./af.png";
import AX from "./ax.png";
import AL from "./al.png";
import DZ from "./dz.png";
import AS from "./as.png";
import AD from "./ad.png";
import AO from "./ao.png";
import AI from "./ai.png";
import AQ from "./aq.png";
import AG from "./ag.png";
import AR from "./ar.png";
import AM from "./am.png";
import AW from "./aw.png";
import AU from "./au.png";
import AT from "./at.png";
import AZ from "./az.png";
import BS from "./bs.png";
import BH from "./bh.png";
import BD from "./bd.png";
import BB from "./bb.png";
import BY from "./by.png";
import BE from "./be.png";
import BZ from "./bz.png";
import BJ from "./bj.png";
import BM from "./bm.png";
import BT from "./bt.png";
import BO from "./bo.png";
import BA from "./ba.png";
import BW from "./bw.png";
import BR from "./br.png";
import IO from "./io.png";
import BN from "./bn.png";
import BG from "./bg.png";
import BF from "./bf.png";
import BI from "./bi.png";
import KH from "./kh.png";
import CM from "./cm.png";
import CA from "./ca.png";
import CV from "./cv.png";
import KY from "./ky.png";
import CF from "./cf.png";
import TD from "./td.png";
import CL from "./cl.png";
import CN from "./cn.png";
import CX from "./cx.png";
import CC from "./cc.png";
import CO from "./co.png";
import KM from "./km.png";
import CG from "./cg.png";
import CD from "./cd.png";
import CK from "./ck.png";
import CR from "./cr.png";
import CI from "./ci.png";
import HR from "./hr.png";
import CU from "./cu.png";
import CY from "./cy.png";
import CZ from "./cz.png";
import DK from "./dk.png";
import DJ from "./dj.png";
import DM from "./dm.png";
import DO from "./do.png";
import EC from "./ec.png";
import EG from "./eg.png";
import SV from "./sv.png";
import GQ from "./gq.png";
import ER from "./er.png";
import EE from "./ee.png";
import ET from "./et.png";
import FK from "./fk.png";
import FO from "./fo.png";
import FJ from "./fj.png";
import FI from "./fi.png";
import FR from "./fr.png";
import GF from "./gf.png";
import PF from "./pf.png";
import GA from "./ga.png";
import GM from "./gm.png";
import GE from "./ge.png";
import DE from "./de.png";
import GH from "./gh.png";
import GI from "./gi.png";
import GR from "./gr.png";
import GL from "./gl.png";
import GD from "./gd.png";
import GP from "./gp.png";
import GU from "./gu.png";
import GT from "./gt.png";
import GG from "./gg.png";
import GN from "./gn.png";
import GW from "./gw.png";
import GY from "./gy.png";
import HT from "./ht.png";
import VA from "./va.png";
import HN from "./hn.png";
import HK from "./hk.png";
import HU from "./hu.png";
import IS from "./is.png";
import IN from "./in.png";
import ID from "./id.png";
import IR from "./ir.png";
import IQ from "./iq.png";
import IE from "./ie.png";
import IM from "./im.png";
import IL from "./il.png";
import IT from "./it.png";
import JM from "./jm.png";
import JP from "./jp.png";
import JE from "./je.png";
import JO from "./jo.png";
import KZ from "./kz.png";
import KE from "./ke.png";
import KI from "./ki.png";
import KP from "./kp.png";
import KR from "./kr.png";
import KW from "./kw.png";
import KG from "./kg.png";
import LA from "./la.png";
import LV from "./lv.png";
import LB from "./lb.png";
import LS from "./ls.png";
import LR from "./lr.png";
import LY from "./ly.png";
import LI from "./li.png";
import LT from "./lt.png";
import LU from "./lu.png";
import MO from "./mo.png";
import MK from "./mk.png";
import MG from "./mg.png";
import MW from "./mw.png";
import MY from "./my.png";
import MV from "./mv.png";
import ML from "./ml.png";
import MT from "./mt.png";
import MH from "./mh.png";
import MQ from "./mq.png";
import MR from "./mr.png";
import MU from "./mu.png";
import YT from "./yt.png";
import MX from "./mx.png";
import FM from "./fm.png";
import MD from "./md.png";
import MC from "./mc.png";
import MN from "./mn.png";
import ME from "./me.png";
import MS from "./ms.png";
import MA from "./ma.png";
import MZ from "./mz.png";
import MM from "./mm.png";
import NA from "./na.png";
import NR from "./nr.png";
import NP from "./np.png";
import NL from "./nl.png";
import AN from "./an.png";
import NC from "./nc.png";
import NZ from "./nz.png";
import NI from "./ni.png";
import NE from "./ne.png";
import NG from "./ng.png";
import NU from "./nu.png";
import NF from "./nf.png";
import MP from "./mp.png";
import NO from "./no.png";
import OM from "./om.png";
import PK from "./pk.png";
import PW from "./pw.png";
import PS from "./ps.png";
import PA from "./pa.png";
import PG from "./pg.png";
import PY from "./py.png";
import PE from "./pe.png";
import PH from "./ph.png";
import PN from "./pn.png";
import PL from "./pl.png";
import PT from "./pt.png";
import PR from "./pr.png";
import QA from "./qa.png";
import RO from "./ro.png";
import RU from "./ru.png";
import RW from "./rw.png";
import RE from "./re.png";
import BL from "./bl.png";
import SH from "./sh.png";
import KN from "./kn.png";
import LC from "./lc.png";
import MF from "./mf.png";
import PM from "./pm.png";
import VC from "./vc.png";
import WS from "./ws.png";
import SM from "./sm.png";
import ST from "./st.png";
import SA from "./sa.png";
import SN from "./sn.png";
import RS from "./rs.png";
import SC from "./sc.png";
import SL from "./sl.png";
import SG from "./sg.png";
import SK from "./sk.png";
import SI from "./si.png";
import SB from "./sb.png";
import SO from "./so.png";
import ZA from "./za.png";
import SS from "./ss.png";
import GS from "./gs.png";
import ES from "./es.png";
import LK from "./lk.png";
import SD from "./sd.png";
import SR from "./sr.png";
import SJ from "./sj.png";
import SZ from "./sz.png";
import SE from "./se.png";
import CH from "./ch.png";
import SY from "./sy.png";
import TW from "./tw.png";
import TJ from "./tj.png";
import TZ from "./tz.png";
import TH from "./th.png";
import TL from "./tl.png";
import TG from "./tg.png";
import TK from "./tk.png";
import TO from "./to.png";
import TT from "./tt.png";
import TN from "./tn.png";
import TR from "./tr.png";
import TM from "./tm.png";
import TC from "./tc.png";
import TV from "./tv.png";
import UG from "./ug.png";
import UA from "./ua.png";
import AE from "./ae.png";
import GB from "./gb.png";
import US from "./us.png";
import UY from "./uy.png";
import UZ from "./uz.png";
import VU from "./vu.png";
import VE from "./ve.png";
import VN from "./vn.png";
import VG from "./vg.png";
import VI from "./vi.png";
import WF from "./wf.png";
import YE from "./ye.png";
import ZM from "./zm.png";
import ZW from "./zw.png";

const flags = {
	AF,
	AX,
	AL,
	DZ,
	AS,
	AD,
	AO,
	AI,
	AQ,
	AG,
	AR,
	AM,
	AW,
	AU,
	AT,
	AZ,
	BS,
	BH,
	BD,
	BB,
	BY,
	BE,
	BZ,
	BJ,
	BM,
	BT,
	BO,
	BA,
	BW,
	BR,
	IO,
	BN,
	BG,
	BF,
	BI,
	KH,
	CM,
	CA,
	CV,
	KY,
	CF,
	TD,
	CL,
	CN,
	CX,
	CC,
	CO,
	KM,
	CG,
	CD,
	CK,
	CR,
	CI,
	HR,
	CU,
	CY,
	CZ,
	DK,
	DJ,
	DM,
	DO,
	EC,
	EG,
	SV,
	GQ,
	ER,
	EE,
	ET,
	FK,
	FO,
	FJ,
	FI,
	FR,
	GF,
	PF,
	GA,
	GM,
	GE,
	DE,
	GH,
	GI,
	GR,
	GL,
	GD,
	GP,
	GU,
	GT,
	GG,
	GN,
	GW,
	GY,
	HT,
	VA,
	HN,
	HK,
	HU,
	IS,
	IN,
	ID,
	IR,
	IQ,
	IE,
	IM,
	IL,
	IT,
	JM,
	JP,
	JE,
	JO,
	KZ,
	KE,
	KI,
	KP,
	KR,
	KW,
	KG,
	LA,
	LV,
	LB,
	LS,
	LR,
	LY,
	LI,
	LT,
	LU,
	MO,
	MK,
	MG,
	MW,
	MY,
	MV,
	ML,
	MT,
	MH,
	MQ,
	MR,
	MU,
	YT,
	MX,
	FM,
	MD,
	MC,
	MN,
	ME,
	MS,
	MA,
	MZ,
	MM,
	NA,
	NR,
	NP,
	NL,
	AN,
	NC,
	NZ,
	NI,
	NE,
	NG,
	NU,
	NF,
	MP,
	NO,
	OM,
	PK,
	PW,
	PS,
	PA,
	PG,
	PY,
	PE,
	PH,
	PN,
	PL,
	PT,
	PR,
	QA,
	RO,
	RU,
	RW,
	RE,
	BL,
	SH,
	KN,
	LC,
	MF,
	PM,
	VC,
	WS,
	SM,
	ST,
	SA,
	SN,
	RS,
	SC,
	SL,
	SG,
	SK,
	SI,
	SB,
	SO,
	ZA,
	SS,
	GS,
	ES,
	LK,
	SD,
	SR,
	SJ,
	SZ,
	SE,
	CH,
	SY,
	TW,
	TJ,
	TZ,
	TH,
	TL,
	TG,
	TK,
	TO,
	TT,
	TN,
	TR,
	TM,
	TC,
	TV,
	UG,
	UA,
	AE,
	GB,
	US,
	UY,
	UZ,
	VU,
	VE,
	VN,
	VG,
	VI,
	WF,
	YE,
	ZM,
	ZW,
};

export default flags;